<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password</title>
</head>
<body>
  <div style="box-sizing: border-box; padding: 20px;">
    <p>Hai {{ $name }},</p>
    <p>Jangan sampe lupa lagi min!!!!!, Klik tautan di bawah ini untuk mereset password Anda:</p>
    <p><a href="{{ $url }}" style="text-decoration: none; background-color: #007bff; color: #fff; padding: 10px 20px; border-radius: 5px;">Reset Password</a></p>
    <p>Jika mimin tidak membuat permintaan ini, mimin dapat mengabaikan email ini.</p>
    <p>Terima kasih,</p>
    <p>KARYCAM</p>
  </div>
</body>
</html>
