<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <div class="w-full bg-gray-600">
        <nav>
            <div class="bg-gray-700">
                <img src="Media/Logo-hitam.png" alt="Logo Kary" class="">
            </div>
            <div class="flex">
                <ul>
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#">Beranda</a></li>
                </ul>
            </div>
        </nav>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\rental_kamera\resources\views/navbarr.blade.php ENDPATH**/ ?>