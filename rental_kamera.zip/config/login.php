<?php

// Simpan ID Admin dan password dalam file ini
$idAdmin = "admin";
$password = "admin";

// Outputkan ID Admin dan password dalam format yang bisa dibaca oleh JavaScript

//ini errornya tadi
//echo $idAdmin . "\n" . $password;
